package modeloDAOJPA;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import modelo.Usuario;
import modeloDAO.UsuarioDAO;

@Repository
public class UsuarioJpaDAO extends JpaDao<Usuario> implements UsuarioDAO {

	public UsuarioJpaDAO() {
		super(Usuario.class);
	}

	@Override
	public Usuario getById(Long id) {
		Usuario resultado = null;
			Query consulta = this.getEntityManager().createQuery("SELECT e FROM " + entityClass.getSimpleName() + " e WHERE e.id = :id");
			consulta.setParameter("id", id);
			try{
				resultado = (Usuario) consulta.getSingleResult();
			}
			catch (NoResultException e){
				resultado = null;
			}
		
		return resultado;
	}
	
}
