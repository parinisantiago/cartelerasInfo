package modeloDAOJPA;

import modelo.Profesor;
import modeloDAO.ProfesorDAO;

public class ProfesorJpaDAO extends JpaDao<Profesor> implements ProfesorDAO{

	public ProfesorJpaDAO() {
		super(Profesor.class);
	}

}
