package modeloDAOJPA;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import modelo.Profesor;
import modelo.Usuario;
import modeloDAO.ProfesorDAO;

@Repository
public class ProfesorJpaDAO extends JpaDao<Profesor> implements ProfesorDAO{

	public ProfesorJpaDAO() {
		super(Profesor.class);
	}

}
