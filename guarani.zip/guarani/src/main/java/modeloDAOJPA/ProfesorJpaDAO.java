package modeloDAOJPA;

import org.springframework.stereotype.Repository;
import modelo.Profesor;
import modeloDAO.ProfesorDAO;

@Repository
public class ProfesorJpaDAO extends JpaDao<Profesor> implements ProfesorDAO{

	public ProfesorJpaDAO() {
		super(Profesor.class);
	}

}
