package modeloDAOJPA;

import org.springframework.stereotype.Repository;

import modelo.Alumno;
import modeloDAO.AlumnoDAO;

@Repository
public class AlumnoJpaDAO extends JpaDao<Alumno> implements AlumnoDAO{

	public AlumnoJpaDAO(){
		super(Alumno.class);
	}
	
}
