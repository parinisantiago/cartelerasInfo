package modeloDAO;

import modelo.Profesor;

public interface ProfesorDAO extends Dao<Profesor>{

}
