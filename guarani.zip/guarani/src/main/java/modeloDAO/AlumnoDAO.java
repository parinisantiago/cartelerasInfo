package modeloDAO;

import modelo.Alumno;

public interface AlumnoDAO extends Dao<Alumno> {
	
}
