package modeloDAO;

import modelo.Usuario;

public interface UsuarioDAO extends Dao<Usuario> {
	public Usuario getByUsername(String username);
}
