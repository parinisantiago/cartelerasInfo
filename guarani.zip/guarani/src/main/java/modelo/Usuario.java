package modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonView;

import rest.JView;

@Entity
@Table(name="usuario")
public abstract class Usuario {
	
	@Id@GeneratedValue
	@Column(name="usuario_id")
	@JsonView(JView.Publico.class)
	private String id;
	
	@Column(nullable = false, unique=true)
	@JsonView(JView.Publico.class)
	private String username;
	
	@Column(nullable = false)
	@JsonView(JView.Privado.class)
	private String password;
	
	@Column(nullable = false)
	@JsonView(JView.Publico.class)
	private String email;
	
	@Column(nullable = false)
	@JsonView(JView.Privado.class)
	private boolean habilitado;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Usuario(){
	}
	
	public Usuario(String user) {
		super();
		this.username = user;
	}

	public Usuario(String username, String password, boolean habilitado) {
		super();
		this.username = username;
		this.password = password;
		this.habilitado = habilitado;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isHabilitado() {
		return habilitado;
	}

	public void setHabilitado(boolean habilitado) {
		this.habilitado = habilitado;
	}
	
	public void deshabilitar(){
		this.setHabilitado(false);
	}
	
	public void habilitar(){
		this.setHabilitado(true);
	}

}
