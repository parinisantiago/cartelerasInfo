package modelo;

import java.util.Set;

import javax.persistence.DiscriminatorValue;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonView;

import rest.JView;

@Entity
@DiscriminatorValue("P")
public class Profesor extends Usuario {
	
	@ElementCollection
	@JsonView(JView.Publico.class)
	private Set<Integer> anios;

	public Set<Integer> getAnios() {
		return anios;
	}

	public void setAnios(Set<Integer> anios) {
		this.anios = anios;
	}

	public boolean hasAnio(Integer anio) {
		return anios.contains(anio);
	}
	
	public void addAnio(Integer anio){
		anios.add(anio);
	}
	
	public void removeAnio(Integer anio){
		anios.remove(anio);
	}
	
}
