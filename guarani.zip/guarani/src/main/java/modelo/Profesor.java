package modelo;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.DiscriminatorValue;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import com.fasterxml.jackson.annotation.JsonView;

import rest.JView;

@Entity
@DiscriminatorValue("P")
public class Profesor extends Usuario {
	
	@ElementCollection(fetch=FetchType.EAGER)
	@JsonView(JView.Publico.class)
	private List<Integer> anios = new ArrayList<Integer>();
	
	public Profesor(){};

	public Profesor(String username, String password) {
		super(username, password);
	}
	
	public Profesor(String username, String password, String email) {
		super(username, password, email);
	}
	
	public Profesor(String username, String password, boolean habilitado) {
		super(username, password, habilitado);
	}

	public Profesor(String username, String password, String email, boolean habilitado) {
		super(username, password, email, habilitado);
	}
	
	public List<Integer> getAnios() {
		return anios;
	}

	public void setAnios(List<Integer> anios) {
		this.anios = anios;
	}

	public boolean hasAnio(Integer anio) {
		return anios.contains(anio);
	}
	
	public void addAnio(Integer anio){
		anios.add(anio);
	}
	
	public void removeAnio(Integer anio){
		anios.remove(anio);
	}
	
}
