package modelo;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("A")
public class Alumno extends Usuario {
	public Alumno(){};

	public Alumno(String username, String password) {
		super(username, password);
	}
	
	public Alumno(String username, String password, String email) {
		super(username, password, email);
	}
	
	public Alumno(String username, String password, boolean habilitado) {
		super(username, password, habilitado);
	}

	public Alumno(String username, String password, String email, boolean habilitado) {
		super(username, password, email, habilitado);
	}
}
