package tokenJWT;

import modelo.Usuario;
import modeloDAO.UsuarioDAO;

public class UserInfoToken{
	
	private long userID;
	private String user;
	private String tipo;
	
	public UserInfoToken(){}
	
	public UserInfoToken(Usuario usuario){
		this.userID = usuario.getId();
		this.user = usuario.getUsername();
		this.tipo = usuario.getClass().getSimpleName();
	}

	public long getUserID() {
		return userID;
	}

	public void setUserID(long userID) {
		this.userID = userID;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Usuario getUsuario(UsuarioDAO dao){
		return dao.getById(userID);
	}
	
	

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return "UserInfoToken [userID=" + userID + ", user=" + user + ", tipo=" + tipo + "]";
	}

}
