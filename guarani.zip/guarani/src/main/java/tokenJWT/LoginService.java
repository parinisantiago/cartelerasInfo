package tokenJWT;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import modelo.Alumno;
import modelo.Profesor;
import modelo.Usuario;
import modeloDAO.AlumnoDAO;
import modeloDAO.ProfesorDAO;


@Service
public class LoginService {
	
	@Autowired
	private AlumnoDAO alumnoDAO;
	@Autowired
	private ProfesorDAO profesorDAO;

	public void logout(Usuario user) {
		
	}
	
	public void logout() {
		
	}
	
	public Alumno loginAlumno(Long id, String password) {
		Alumno u = alumnoDAO.getById(id);
		if(u != null){
			if(u.isHabilitado() && u.getPassword().equals(password)){
				return u;
			}
		}
		throw new IllegalArgumentException("Usuario o password invalido");
	}
	
	public Profesor loginProfesor(Long id, String password) {
		Profesor u = profesorDAO.getById(id);
		if(u != null){
			if(u.isHabilitado() && u.getPassword().equals(password)){
				return u;
			}
		}
		throw new IllegalArgumentException("Usuario o password invalido");
	}

	
}
