package rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import modelo.Alumno;
import modelo.Profesor;
import modeloDAO.AlumnoDAO;
import modeloDAO.ProfesorDAO;

@RestController
public class CargarDatosREST {
	@Autowired
	private AlumnoDAO daoAlumno;
	@Autowired
	private ProfesorDAO daoProfesor;
	
	@RequestMapping(value="/cargardatos", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> cargaDeDatos(){
		Alumno usuarioEuge = new Alumno("Euge", "piturro", "euge@mail",true);
		Alumno usuarioAgus = new Alumno("Agus", "agus", "agus@mail",true);
		Profesor usuarioProfesor = new Profesor("Profe", "profe", "profe@mail",true);
		
		daoAlumno.persist(usuarioAgus);
		daoAlumno.persist(usuarioEuge);
		daoProfesor.persist(usuarioProfesor);
		
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
