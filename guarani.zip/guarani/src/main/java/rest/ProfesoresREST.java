package rest;

import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;

import modelo.Alumno;
import modelo.Profesor;

@RestController
public class ProfesoresREST extends UsuarioREST<Profesor> {
	
    @RequestMapping(value="/profesor/{id}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @JsonView(JView.Publico.class)
    @Override
    public ResponseEntity<Profesor> usuarioById(@PathVariable("id") Long id) {
    	return super.usuarioById(id);
    }
    
    @RequestMapping(value="/profesor", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @JsonView(JView.Publico.class)
    @Override
    public ResponseEntity<List<Profesor>> listAll() {
    	return super.listAll();
    }
    
    @RequestMapping(value="/profesor/chequearlogin", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @Override
    public ResponseEntity<?> login(@RequestBody String checkJson) {
    	return super.login(checkJson);
    }
    
    @Override
	protected Profesor checkLogin(Long id, String password) {
		return this.getLoginService().loginProfesor(id, password);
	}
    
}