package rest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import modelo.Profesor;
import modeloDAO.ProfesorDAO;

@RestController
public class ProfesoresREST {
	@Autowired
	private ProfesorDAO dao;
	
    @RequestMapping(value="/profesores/{id}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @JsonView(JView.Publico.class)
    public ResponseEntity<Profesor> usuarioById(@PathVariable("id") Long id) {
    	Profesor user = dao.getById(new Long(id));
    	if( user != null && user.isHabilitado()){
    		return new ResponseEntity<Profesor>(user, HttpStatus.OK);
    	}
    	else{
    		return new ResponseEntity<Profesor>(HttpStatus.NOT_FOUND);
    	}
    }
    
    @RequestMapping(value="/profesores", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @JsonView(JView.Publico.class)
    public ResponseEntity<List<Profesor>> listAll() {
    	List<Profesor> users = dao.selectAll();
    	if( users == null ){
    		users = new ArrayList<Profesor>();
    	}
		return new ResponseEntity<List<Profesor>>(users, HttpStatus.OK);
    }
    
    //TODO cambiar a get, lo pude hacer andar con post solamente (el get no me tomaba el cuerpo)
    @RequestMapping(value="/profesores/chequearlogin", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @JsonView(JView.Publico.class)
    public ResponseEntity<Profesor> chequearLoguin(@RequestBody String checkJson) {
    	System.out.println("JSONREQ: "+checkJson);
		ProfesorCheck check = new ProfesorCheck();
		try {
			check = new ObjectMapper().readValue(checkJson, ProfesorCheck.class);
			System.out.println(check);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	Profesor user = dao.getById(check.getId());
    	if( user != null && user.isHabilitado() && user.getPassword().equals(check.getPassword())){
    		return new ResponseEntity<Profesor>(user, HttpStatus.OK);
    	}
    	else{
    		return new ResponseEntity<Profesor>(user, HttpStatus.UNAUTHORIZED);
    	}
    	
    }
    
    private static class ProfesorCheck{
    	private Long id;
    	private String password;
    	
    	public ProfesorCheck() {
		}
    	
		public ProfesorCheck(Long id, String password) {
			super();
			this.id = id;
			this.password = password;
		}

		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}

		@Override
		public String toString() {
			return "ProfesorCheck {'id':"+id.toString()+", 'password':"+password+"}";
		}
    }
}
    	
