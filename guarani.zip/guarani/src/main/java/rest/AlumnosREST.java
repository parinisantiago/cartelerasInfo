package rest;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import modelo.Alumno;
import modeloDAO.AlumnoDAO;


@RestController
public class AlumnosREST {
	@Autowired
	private AlumnoDAO dao;
	
    @RequestMapping(value="/alumnos/{id}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @JsonView(JView.Publico.class)
    public ResponseEntity<Alumno> usuarioById(@PathVariable("id") Long id) {
    	Alumno user = dao.getById(id);
    	if( user != null && user.isHabilitado()){
    		return new ResponseEntity<Alumno>(user, HttpStatus.OK);
    	}
    	else{
    		return new ResponseEntity<Alumno>(HttpStatus.NOT_FOUND);
    	}
    }
    
    @RequestMapping(value="/alumnos", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @JsonView(JView.Publico.class)
    public ResponseEntity<List<Alumno>> listAll() {
    	List<Alumno> users = dao.selectAll();
    	if( users == null ){
    		users = new ArrayList<Alumno>();
    	}
		return new ResponseEntity<List<Alumno>>(users, HttpStatus.OK);
    }
    
    //TODO cambiar a get, lo pude hacer andar con post solamente (el get no me tomaba el cuerpo)
    @RequestMapping(value="/alumnos/chequearlogin", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @JsonView(JView.Publico.class)
    public ResponseEntity<Alumno> chequearLoguin(@RequestBody String checkJson) {
    	System.out.println("JSONREQ: "+checkJson);
		AlumnoCheck check = new AlumnoCheck();
		try {
			check = new ObjectMapper().readValue(checkJson, AlumnoCheck.class);
			System.out.println(check);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	Alumno user = dao.getById(check.getId());
    	if( user != null && user.isHabilitado() && user.getPassword().equals(check.getPassword())){
    		return new ResponseEntity<Alumno>(user, HttpStatus.OK);
    	}
    	else{
    		return new ResponseEntity<Alumno>(user, HttpStatus.UNAUTHORIZED);
    	}
    	
    }
    
    private static class AlumnoCheck implements Serializable{
    	private Long id;
    	private String password;
    	
    	public AlumnoCheck() {
		}
    	
		public AlumnoCheck(Long id, String password) {
			super();
			this.id = id;
			this.password = password;
		}

		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}

		@Override
		public String toString() {
			return "AlumnoCheck [id=" + id + ", password=" + password + "]";
		}
    	
    }
}
