package rest;

import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import modelo.Alumno;


@RestController
public class AlumnosREST extends UsuarioREST<Alumno> {
	
    @RequestMapping(value="/alumno/{id}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @JsonView(JView.Publico.class)
    @Override
    public ResponseEntity<Alumno> usuarioById(@PathVariable("id") Long id) {
    	return super.usuarioById(id);
    }
    
    @RequestMapping(value="/alumno", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @JsonView(JView.Publico.class)
    @Override
    public ResponseEntity<List<Alumno>> listAll() {
    	return super.listAll();
    }
    
    @RequestMapping(value="/alumno/chequearlogin", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @Override
    public ResponseEntity<?> login(@RequestBody String checkJson) {
    	return super.login(checkJson);
    }

	@Override
	protected Alumno checkLogin(Long id, String password) {
		return this.getLoginService().loginAlumno(id, password);
	}
}
