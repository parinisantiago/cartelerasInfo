package rest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import com.fasterxml.jackson.databind.ObjectMapper;

import modelo.Usuario;
import modeloDAO.Dao;
import tokenJWT.LoginService;
import tokenJWT.TokenJWT;
import tokenJWT.TokenJWTManager;

public abstract class UsuarioREST<T extends Usuario> {
	@Autowired
	private Dao<T> dao;
	@Autowired
	private LoginService loginService;
	@Autowired
	private TokenJWTManager tokenManagerSecurity;
	
	protected LoginService getLoginService(){
		return loginService;
	}
	
	protected abstract T checkLogin(Long id, String password);
	
    public ResponseEntity<T> usuarioById(@PathVariable("id") Long id) {
    	T user = dao.getById(id);
    	if( user != null && user.isHabilitado()){
    		return new ResponseEntity<T>(user, HttpStatus.OK);
    	}
    	else{
    		return new ResponseEntity<T>(HttpStatus.NOT_FOUND);
    	}
    }

    public ResponseEntity<List<T>> listAll() {
    	List<T> users = dao.selectAll();
    	if( users == null ){
    		users = new ArrayList<T>();
    	}
		return new ResponseEntity<List<T>>(users, HttpStatus.OK);
    }
    
    public ResponseEntity<?> login(@RequestBody String jsonString) {
		try {
			//parseo lo enviado en el post
			UsuarioCheck userPost = new ObjectMapper().readValue(jsonString, UsuarioCheck.class);
			
			//chequeo el login (login service se encarga de buscar el usuario por nombre y comparar la contraseña
			T user = checkLogin(userPost.getId(), userPost.getPassword());
			
			//si todo salio bien, se crea el token y se envia
			TokenJWT token = new TokenJWT(tokenManagerSecurity.createJWT(user));
			
			return ResponseEntity.ok("{\"token\":\""+token.toString()+"\"}");
		} catch (Exception e) {
			return new ResponseEntity<>(Collections.singletonMap("AuthenticationException",e.getMessage()), HttpStatus.UNAUTHORIZED);
		}
	}
    
    private static class UsuarioCheck{
    	private Long id;
    	private String password;
    	
    	public UsuarioCheck() {
		}
    	
		public UsuarioCheck(Long id, String password) {
			super();
			this.id = id;
			this.password = password;
		}

		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}

		@Override
		public String toString() {
			return "UsuarioCheck {'id':"+id.toString()+", 'password':"+password+"}";
		}
    }
}
