package rest;

public class JView {
	public interface Publico{}
	public interface Privado extends Publico{}
}
